import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({answer:"Giao diện AI đã sẵn sàng nhưng chưa có khóa API. Thêm OPENAI_API_KEY vào .env.local để bật gia sư AI thật."});
  }
  try {
    const body = await request.json();
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const client = new OpenAI({apiKey: process.env.OPENAI_API_KEY});
    const result = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      messages: [
        {role:"system",content:"Bạn là gia sư AI thân thiện, dạy bằng tiếng Việt. Giải thích rõ từng bước, khuyến khích người học tự suy luận và không bịa dữ kiện."},
        ...messages.slice(-12).filter((m: {role?:string;text?:string}) => (m.role==="user"||m.role==="assistant") && typeof m.text==="string").map((m: {role:"user"|"assistant";text:string})=>({role:m.role,content:m.text}))
      ],
      temperature:0.5
    });
    return NextResponse.json({answer:result.choices[0]?.message?.content ?? "AI chưa tạo được câu trả lời."});
  } catch {
    return NextResponse.json({error:"Có lỗi khi xử lý yêu cầu AI."},{status:500});
  }
}