# Learning Hub — Backend + PostgreSQL

## Thành phần đã thêm
- PostgreSQL + Prisma ORM.
- Đăng ký, đăng nhập, đăng xuất bằng JWT trong cookie `HttpOnly`.
- Mật khẩu được băm bằng bcrypt (12 vòng).
- API môn học, khóa học, phiên học và nộp bài kiểm tra.
- Frontend đã nối form đăng ký/đăng nhập với cookie phiên, danh sách môn học với PostgreSQL và chức năng ghi nhận phút học.
- Kiểm tra dữ liệu đầu vào bằng Zod.
- API yêu cầu đăng nhập; dữ liệu môn học/khóa học được giới hạn theo chủ tài khoản.

## 1. Yêu cầu
- Node.js 20+
- PostgreSQL 14+ (cài local hoặc dùng dịch vụ PostgreSQL)
- npm

## 2. Cài đặt
Giải nén dự án, mở terminal tại thư mục `learning-hub`, chạy:

```bash
npm install
```

Tạo database PostgreSQL tên `learning_hub`, sau đó sao chép `.env.example` thành `.env.local` và sửa:

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/learning_hub?schema=public"
AUTH_SECRET="chuoi-bi-mat-ngau-nhien-dai-it-nhat-32-ky-tu"
OPENAI_API_KEY=""
OPENAI_MODEL="gpt-4.1-mini"
```

Có thể tạo secret bằng `openssl rand -base64 32`.

## 3. Tạo bảng dữ liệu
```bash
npx prisma generate
npx prisma migrate dev --name init
```

Chạy ứng dụng:
```bash
npm run dev
```
Mở `http://localhost:3000`.

## 4. API hiện có

| Method | Endpoint | Mô tả |
|---|---|---|
| POST | `/api/auth/register` | Tạo tài khoản, tự đăng nhập |
| POST | `/api/auth/login` | Đăng nhập |
| POST | `/api/auth/logout` | Đăng xuất |
| GET | `/api/auth/me` | Lấy tài khoản đang đăng nhập |
| GET/POST | `/api/subjects` | Liệt kê / tạo môn học |
| GET/POST | `/api/courses` | Liệt kê / tạo khóa học |
| GET/POST | `/api/study-sessions` | Xem / ghi phiên học |
| POST | `/api/quizzes/:id/submit` | Nộp câu trả lời và chấm điểm |

### Ví dụ đăng ký
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Minh","email":"minh@example.com","password":"matkhau123"}'
```

### Ví dụ tạo môn học (sau khi đăng nhập bằng trình duyệt hoặc lưu cookie)
```bash
curl -X POST http://localhost:3000/api/subjects \
  -H "Content-Type: application/json" \
  -b cookies.txt -c cookies.txt \
  -d '{"name":"Vật lý","color":"#4568f5"}'
```

## 5. Cấu trúc dữ liệu
`User → Subject → Course → Lesson → Material`; ngoài ra có `Quiz`, `Question`, `QuizAttempt`, `Answer`, `StudySession`, `AIConversation`, `AIMessage`.

## 6. Frontend đã kết nối
- Khi mở trang chủ, ứng dụng kiểm tra phiên tại `/api/auth/me`.
- Chưa đăng nhập: hiển thị form đăng nhập/đăng ký.
- Đăng nhập thành công: tải môn học và tổng thời gian học từ database.
- Có thể tạo môn học ngay trên dashboard; dữ liệu được lưu theo tài khoản.
- Có thể ghi nhận số phút học; dữ liệu được lưu trong `StudySession`.
- Nút đăng xuất xóa cookie phiên.

## 7. Quan trọng về bảo mật
- Không gửi `AUTH_SECRET`, `DATABASE_URL` hoặc `OPENAI_API_KEY` lên frontend.
- Không commit `.env.local` lên Git. `.env.example` chỉ chứa giá trị mẫu.
- Bật HTTPS khi deploy production.
- Bổ sung rate limiting, xác minh email, khôi phục mật khẩu, CSRF/origin checks và quy trình kiểm duyệt nội dung trước khi mở cho người dùng thật.
- Bản này là nền tảng MVP. Chưa có upload file thật, CRUD bài học/câu hỏi, phân quyền quản trị, xác minh email hoặc khôi phục mật khẩu.
- API chấm điểm dùng đáp án lưu trong database; không gửi `correctAnswer` về client khi xây API lấy đề.

## Hệ thống thi trắc nghiệm

Mở `http://localhost:3000/thi` sau khi đăng nhập. Phân hệ gồm:
- Tạo đề với tên, mô tả, thời gian, câu hỏi 4 lựa chọn, đáp án đúng, giải thích và độ khó.
- Lưu đề riêng tư hoặc công khai để người dùng khác có thể làm.
- Bắt đầu lượt thi riêng, bộ đếm thời gian, lưu câu trả lời trên giao diện và nộp bài.
- Chấm điểm ở máy chủ; đáp án đúng không được gửi xuống trình duyệt trước khi nộp.
- Xem kết quả, đáp án, lựa chọn đã chọn và giải thích; xem lại lịch sử tối đa 100 lượt thi đã nộp.

### Cập nhật database sau khi tải phiên bản này

Vì schema Prisma đã được mở rộng, chạy:
```bash
npx prisma generate
npx prisma migrate dev --name quiz_center
```
Sau đó khởi động lại ứng dụng:
```bash
npm run dev
```

API chính:
- `GET/POST /api/quizzes` — danh sách đề và tạo đề.
- `GET /api/quizzes/:id` — chi tiết đề, không trả đáp án đúng.
- `POST /api/quizzes/:id/start` — tạo lượt thi.
- `POST /api/quizzes/:id/submit` — chấm và lưu kết quả.
- `GET /api/quiz-attempts` — lịch sử cá nhân.
- `GET /api/quiz-attempts/:id` — xem lại một lượt thi.

## Thư viện tự học Python
Mở `http://localhost:3000/tai-nguyen`. Trang này chỉ chứa tài nguyên học Python, phân loại theo chủ đề và lộ trình 12 tuần. Danh mục lưu metadata và liên kết đến nguồn gốc; không tải hoặc sao chép nội dung có bản quyền. Tài liệu gồm Microsoft Learn (tiếng Việt), Python Documentation, Harvard CS50P, Google Python Class, Exercism và Automate the Boring Stuff.
