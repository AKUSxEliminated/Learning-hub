import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
export async function POST(_req: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const { id } = await context.params;
  const quiz = await prisma.quiz.findFirst({ where: { id, OR: [{ createdById: user.id }, { isPublished: true }] }, include: { _count: { select: { questions: true } } } });
  if (!quiz || quiz._count.questions === 0) return NextResponse.json({ error: "Đề thi không tồn tại hoặc chưa có câu hỏi." }, { status: 404 });
  const attempt = await prisma.quizAttempt.create({ data: { userId: user.id, quizId: id, totalQuestions: quiz._count.questions } });
  return NextResponse.json({ attemptId: attempt.id, startedAt: attempt.startedAt, durationMinutes: quiz.durationMinutes });
}
