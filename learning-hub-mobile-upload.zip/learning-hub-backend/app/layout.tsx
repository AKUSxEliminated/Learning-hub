import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Learning Hub", description: "Không gian học tập cá nhân" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="vi"><body>{children}</body></html>;
}