import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

const questionSchema = z.object({
  prompt: z.string().trim().min(5).max(2000),
  options: z.array(z.string().trim().min(1).max(500)).length(4),
  correctAnswer: z.string().min(1),
  explanation: z.string().max(2000).optional().nullable(),
  difficulty: z.enum(["easy", "medium", "hard"]).default("medium")
}).refine(q => q.options.includes(q.correctAnswer), { message: "Đáp án đúng phải trùng với một lựa chọn." });
const createSchema = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().max(1000).optional().nullable(),
  durationMinutes: z.number().int().min(1).max(300),
  isPublished: z.boolean().default(false),
  questions: z.array(questionSchema).min(1).max(100)
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const quizzes = await prisma.quiz.findMany({
    where: { OR: [{ createdById: user.id }, { isPublished: true }] },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { questions: true, attempts: true } }, createdBy: { select: { name: true } } }
  });
  return NextResponse.json({ quizzes });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const parsed = createSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message || "Dữ liệu đề thi không hợp lệ." }, { status: 400 });
  const { questions, ...data } = parsed.data;
  const quiz = await prisma.quiz.create({
    data: {
      ...data, createdById: user.id,
      questions: { create: questions.map((q, position) => ({ position, question: { create: { ...q, createdById: user.id } } })) }
    },
    include: { _count: { select: { questions: true } } }
  });
  return NextResponse.json({ quiz }, { status: 201 });
}
