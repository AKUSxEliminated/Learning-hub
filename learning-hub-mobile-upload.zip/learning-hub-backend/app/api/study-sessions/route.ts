import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

const schema = z.object({
  minutes: z.number().int().min(1).max(1440),
  note: z.string().trim().max(300).optional()
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const [sessions, aggregate] = await Promise.all([
    prisma.studySession.findMany({ where: { userId: user.id }, orderBy: { startedAt: "desc" }, take: 30 }),
    prisma.studySession.aggregate({ where: { userId: user.id }, _sum: { minutes: true }, _count: true })
  ]);
  return NextResponse.json({ sessions, totalMinutes: aggregate._sum.minutes ?? 0, totalSessions: aggregate._count });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Số phút học phải từ 1 đến 1440." }, { status: 400 });
  const session = await prisma.studySession.create({ data: { ...parsed.data, userId: user.id } });
  return NextResponse.json({ session }, { status: 201 });
}
