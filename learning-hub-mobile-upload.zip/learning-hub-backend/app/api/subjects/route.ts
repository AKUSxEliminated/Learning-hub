import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

const schema = z.object({
  name: z.string().trim().min(1).max(80),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional()
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const subjects = await prisma.subject.findMany({
    where: { userId: user.id },
    include: { courses: { include: { _count: { select: { lessons: true } } } } },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ subjects });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Tên môn học không hợp lệ." }, { status: 400 });
  const subject = await prisma.subject.create({
    data: { ...parsed.data, userId: user.id }
  });
  return NextResponse.json({ subject }, { status: 201 });
}
