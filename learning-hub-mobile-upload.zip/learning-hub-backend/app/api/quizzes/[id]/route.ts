import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(_req: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const { id } = await context.params;
  const quiz = await prisma.quiz.findFirst({
    where: { id, OR: [{ createdById: user.id }, { isPublished: true }] },
    include: { questions: { orderBy: { position: "asc" }, include: { question: { select: { id: true, prompt: true, options: true, difficulty: true } } } }, createdBy: { select: { name: true } } }
  });
  if (!quiz) return NextResponse.json({ error: "Không tìm thấy đề thi." }, { status: 404 });
  return NextResponse.json({ quiz });
}
