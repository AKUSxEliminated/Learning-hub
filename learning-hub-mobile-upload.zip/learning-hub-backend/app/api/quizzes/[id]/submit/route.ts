import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
const schema = z.object({ attemptId: z.string().min(1), answers: z.array(z.object({ questionId: z.string().min(1), response: z.string().max(500) })).max(100) });
export async function POST(req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const { id: quizId } = await context.params;
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Dữ liệu bài làm không hợp lệ." }, { status: 400 });
  const attempt = await prisma.quizAttempt.findFirst({ where: { id: parsed.data.attemptId, quizId, userId: user.id, submittedAt: null } });
  if (!attempt) return NextResponse.json({ error: "Không tìm thấy lượt thi đang làm hoặc lượt thi đã nộp." }, { status: 404 });
  const quiz = await prisma.quiz.findUnique({ where: { id: quizId }, include: { questions: { orderBy: { position: "asc" }, include: { question: true } } } });
  if (!quiz || quiz.questions.length === 0) return NextResponse.json({ error: "Đề thi không hợp lệ." }, { status: 404 });
  const submitted = new Map(parsed.data.answers.map(a => [a.questionId, a.response]));
  const validIds = new Set(quiz.questions.map(q => q.questionId));
  if ([...submitted.keys()].some(id => !validIds.has(id))) return NextResponse.json({ error: "Bài làm chứa câu hỏi không thuộc đề thi." }, { status: 400 });
  const records = quiz.questions.map(item => {
    const response = (submitted.get(item.questionId) || "").trim();
    const isCorrect = response.length > 0 && response.toLocaleLowerCase() === item.question.correctAnswer.trim().toLocaleLowerCase();
    return { questionId: item.questionId, response, isCorrect };
  });
  const correct = records.filter(r => r.isCorrect).length;
  const score = Math.round(correct / quiz.questions.length * 10000) / 100;
  const finishedAt = new Date();
  const saved = await prisma.$transaction(async tx => {
    await tx.answer.createMany({ data: records.map(r => ({ attemptId: attempt.id, questionId: r.questionId, response: r.response, isCorrect: r.isCorrect })) });
    return tx.quizAttempt.update({ where: { id: attempt.id }, data: { score, correctCount: correct, totalQuestions: quiz.questions.length, submittedAt: finishedAt }, select: { id: true, score: true, correctCount: true, totalQuestions: true, startedAt: true, submittedAt: true } });
  });
  return NextResponse.json({ attempt: saved, wrong: quiz.questions.length - correct - records.filter(r => !r.response).length, unanswered: records.filter(r => !r.response).length, review: quiz.questions.map((q, i) => ({ questionId: q.questionId, prompt: q.question.prompt, options: q.question.options, correctAnswer: q.question.correctAnswer, explanation: q.question.explanation, response: records[i].response, isCorrect: records[i].isCorrect })) });
}
