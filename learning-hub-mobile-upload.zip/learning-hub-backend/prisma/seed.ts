import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const email = "demo@learninghub.local";
  const user = await prisma.user.upsert({
    where: { email },
    update: {},
    create: { email, name: "Người học demo", passwordHash: "CHANGE_ME_USE_REGISTER_ENDPOINT" }
  });
  const subjects = [
    { name: "Python cơ bản", color: "#4568f5" },
    { name: "Năng lượng tái tạo", color: "#20a779" },
    { name: "Toán học", color: "#f2aa4c" }
  ];
  for (const item of subjects) {
    await prisma.subject.upsert({
      where: { id: `${user.id}-${item.name.toLowerCase().replaceAll(" ", "-")}` },
      update: {},
      create: { id: `${user.id}-${item.name.toLowerCase().replaceAll(" ", "-")}`, ...item, userId: user.id }
    });
  }
  console.log("Đã tạo dữ liệu môn học mẫu cho", email);
  console.log("Tạo tài khoản đăng nhập bằng API /api/auth/register để đặt mật khẩu an toàn.");
}
main().catch(e => { console.error(e); process.exit(1); }).finally(async () => prisma.$disconnect());
