import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
export async function GET(_req: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const { id } = await context.params;
  const attempt = await prisma.quizAttempt.findFirst({ where: { id, userId: user.id }, include: { quiz: { include: { questions: { orderBy: { position: "asc" }, include: { question: true } } } }, answers: true } });
  if (!attempt) return NextResponse.json({ error: "Không tìm thấy lịch sử bài thi." }, { status: 404 });
  const answerMap = new Map(attempt.answers.map(a => [a.questionId, a]));
  return NextResponse.json({ attempt, review: attempt.quiz.questions.map(q => { const a = answerMap.get(q.questionId); return { questionId: q.questionId, prompt: q.question.prompt, options: q.question.options, correctAnswer: q.question.correctAnswer, explanation: q.question.explanation, response: typeof a?.response === "string" ? a.response : "", isCorrect: a?.isCorrect ?? false }; }) });
}
