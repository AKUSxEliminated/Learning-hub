import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const attempts = await prisma.quizAttempt.findMany({ where: { userId: user.id, submittedAt: { not: null } }, orderBy: { startedAt: "desc" }, take: 100, include: { quiz: { select: { id: true, title: true, durationMinutes: true } } } });
  return NextResponse.json({ attempts });
}
