 "use client";
import { useEffect, useState } from "react";
import { Activity, ArrowRight, BookOpen, BrainCircuit, Check, Clock3, FileText, Flame, GraduationCap, LayoutDashboard, Menu, Plus, Search, Settings2, Sparkles, Target, TrendingUp } from "lucide-react";

const tasksInitial = [
  {id:1,title:"Ôn tập tích phân suy rộng",subject:"Toán cao cấp",time:"08:30 · 25 phút",done:false},
  {id:2,title:"Đọc chương 2 — Năng lượng mặt trời",subject:"Năng lượng tái tạo",time:"14:00 · 35 phút",done:false},
  {id:3,title:"Làm 10 câu trắc nghiệm Python",subject:"Lập trình",time:"19:30 · 20 phút",done:true}
];
const nav = [{name:"Tổng quan",icon:LayoutDashboard},{name:"Môn học",icon:BookOpen},{name:"Luyện thi",icon:GraduationCap},{name:"Tài liệu",icon:FileText},{name:"Gia sư AI",icon:BrainCircuit}];

export default function Home(){
 const [active,setActive]=useState("Tổng quan");
 const [tasks,setTasks]=useState(tasksInitial);
 const [question,setQuestion]=useState("");
 const [messages,setMessages]=useState([{role:"assistant",text:"Chào mày! Tao là gia sư AI của Learning Hub. Hôm nay mày muốn học chủ đề gì?"}]);
 const [busy,setBusy]=useState(false);
 const [notice,setNotice]=useState("");
 const [user,setUser]=useState<{id:string;name:string;email:string}|null>(null);
 const [authMode,setAuthMode]=useState<"login"|"register">("login");
 const [authName,setAuthName]=useState("");
 const [authEmail,setAuthEmail]=useState("");
 const [authPassword,setAuthPassword]=useState("");
 const [authError,setAuthError]=useState("");
 const [authBusy,setAuthBusy]=useState(false);
 const [subjects,setSubjects]=useState<any[]>([]);
 const [newSubject,setNewSubject]=useState("");
 const [sessionMinutes,setSessionMinutes]=useState("30");
 const [backendBusy,setBackendBusy]=useState(false);
 const done=tasks.filter(t=>t.done).length;

 async function loadBackendData(){
  const [sr, tr] = await Promise.all([fetch("/api/subjects"),fetch("/api/study-sessions")]);
  if(sr.ok){const d=await sr.json();setSubjects(d.subjects||[]);}
  if(tr.ok){const d=await tr.json();setNotice(`Dữ liệu đã đồng bộ · Tổng thời gian học đã ghi nhận: ${d.totalMinutes||0} phút.`);}
 }
 useEffect(()=>{fetch("/api/auth/me").then(async r=>{if(r.ok){const d=await r.json();setUser(d.user);await loadBackendData();}}).catch(()=>{});},[]);
 async function submitAuth(e:React.FormEvent){
  e.preventDefault();setAuthBusy(true);setAuthError("");
  try{
   const endpoint=authMode==="register"?"/api/auth/register":"/api/auth/login";
   const body=authMode==="register"?{name:authName,email:authEmail,password:authPassword}:{email:authEmail,password:authPassword};
   const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
   const d=await r.json();if(!r.ok)throw new Error(d.error||"Không thể xác thực tài khoản.");
   setUser(d.user);setAuthPassword("");await loadBackendData();
  }catch(err){setAuthError(err instanceof Error?err.message:"Có lỗi xảy ra.");}
  finally{setAuthBusy(false);}
 }
 async function logout(){await fetch("/api/auth/logout",{method:"POST"});setUser(null);setSubjects([]);}
 async function addSubject(e:React.FormEvent){
  e.preventDefault();if(!newSubject.trim())return;setBackendBusy(true);
  try{const r=await fetch("/api/subjects",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:newSubject.trim()})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Không thêm được môn học.");setSubjects(old=>[d.subject,...old]);setNewSubject("");}
  catch(err){setNotice(err instanceof Error?err.message:"Có lỗi khi thêm môn học.");}
  finally{setBackendBusy(false);}
 }
 async function saveStudySession(){
  const minutes=Number(sessionMinutes);if(!Number.isInteger(minutes)||minutes<1||minutes>1440){setNotice("Nhập số phút học từ 1 đến 1440.");return;}
  setBackendBusy(true);try{const r=await fetch("/api/study-sessions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({minutes,note:"Ghi nhận từ bảng điều khiển"})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Không lưu được phiên học.");setNotice(`Đã lưu phiên học ${d.session.minutes} phút vào cơ sở dữ liệu.`);}
  catch(err){setNotice(err instanceof Error?err.message:"Có lỗi khi lưu phiên học.");}
  finally{setBackendBusy(false);}
 }
 async function ask(e:React.FormEvent){
  e.preventDefault(); const q=question.trim(); if(!q||busy)return;
  setMessages(old=>[...old,{role:"user",text:q}]);setQuestion("");setBusy(true);
  try{
   const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:[...messages,{role:"user",text:q}]})});
   const data=await r.json();setMessages(old=>[...old,{role:"assistant",text:data.answer||data.error||"Chưa có phản hồi."}]);
  }catch{setMessages(old=>[...old,{role:"assistant",text:"Không kết nối được máy chủ AI."}]);}
  finally{setBusy(false);}
 }
 return <main className="shell">
  <aside className="sidebar">
   <div className="brand"><div className="brandmark"><BrainCircuit/></div><div><b>learning<span>hub</span></b><small>YOUR PERSONAL SPACE</small></div></div>
   <p className="navlabel">KHÔNG GIAN CỦA MÀY</p>
   {nav.map(({name,icon:Icon})=><button key={name} className={"navitem "+(active===name?"selected":"")} onClick={()=>{if(name==="Luyện thi"){window.location.href="/thi";return;}setActive(name);setNotice(name==="Tổng quan"||name==="Gia sư AI"?"":`Phân hệ ${name} sẽ được triển khai ở giai đoạn tiếp theo.`);if(name==="Gia sư AI")document.getElementById("tutor")?.scrollIntoView({behavior:"smooth"});}}><Icon size={18}/>{name}{name==="Gia sư AI"&&<em>AI</em>}</button>)}
   <div className="sidebottom"><div className="streak"><Flame/><div><b>3 ngày liên tiếp</b><small>Giữ nhịp học tập nhé!</small></div></div><button className="navitem"><Settings2 size={18}/>Cài đặt</button><div className="profile"><div className="avatar">{user?.name?.slice(0,2).toUpperCase()||"HV"}</div><div style={{flex:1,minWidth:0}}><b>{user?.name||"Học viên"}</b><small>{user?.email||"Tài khoản cá nhân"}</small></div>{user&&<button onClick={logout} title="Đăng xuất" style={{border:0,background:"none",color:"#999"}}>↪</button>}</div></div>
  </aside>
  <section className="main">
   <header className="topbar"><div className="crumb">Không gian học tập <span>/</span> <b>{active}</b></div><div className="search"><Search size={16}/><input placeholder="Tìm bài học, tài liệu..."/></div><div className="avatar">{user?.name?.slice(0,2).toUpperCase()||"HV"}</div></header>
   <div className="content">
    <div className="welcome"><div><div className="eyebrow">● THỨ HAI · KHỞI ĐỘNG TUẦN MỚI</div><h1>Chào mày, hôm nay học gì? <span>✦</span></h1><p>Mỗi ngày một chút, kiến thức sẽ tạo nên khác biệt lớn.</p></div><button className="primary" onClick={()=>setNotice("Chức năng tạo kế hoạch sẽ được kết nối ở giai đoạn tiếp theo.")}><Plus size={16}/>Tạo kế hoạch</button></div>
    {notice&&<div className="notice">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
    <div className="stats">
     <article className="stat"><div>Thời gian học tuần này <Clock3/></div><strong>4.5 <small>giờ</small></strong><p><TrendingUp/> Mục tiêu: 7 giờ / tuần</p><div className="bar"><i style={{width:"64%"}}/></div></article>
     <article className="stat"><div>Bài học đã hoàn thành <Check/></div><strong>18 <small>bài</small></strong><p className="green">+4 bài trong tuần này</p><div className="bar"><i style={{width:"72%"}}/></div></article>
     <article className="stat"><div>Chuỗi ngày học <Flame/></div><strong>3 <small>ngày</small></strong><p>Cố gắng duy trì mỗi ngày</p><div className="dots"><i/><i/><i/><i/><i/><i/><i/></div></article>
     <article className="stat"><div>Mục tiêu tháng <Target/></div><strong>68<small>%</small></strong><p>Còn 32% để hoàn thành</p><div className="bar"><i style={{width:"68%"}}/></div></article>
    </div>
    <div className="grid">
     <section className="panel"><div className="panelhead"><div><label>STAY ON TRACK</label><h2>Kế hoạch hôm nay</h2></div><a>Xem lịch <ArrowRight size={14}/></a></div><div className="taskmeta"><span>{done}/{tasks.length} nhiệm vụ hoàn thành</span><b>{Math.round(done/tasks.length*100)}%</b></div><div className="bar"><i style={{width:`${done/tasks.length*100}%`}}/></div>
      {tasks.map(t=><div className="task" key={t.id}><button className={"check "+(t.done?"checked":"")} onClick={()=>setTasks(old=>old.map(x=>x.id===t.id?{...x,done:!x.done}:x))}>{t.done&&<Check size={13}/>}</button><div className="tasktext"><b>{t.title}</b><small>{t.subject}</small></div><time>{t.time}</time></div>)}<button className="add" onClick={()=>setNotice("Biểu mẫu thêm nhiệm vụ sẽ được bổ sung ở giai đoạn kế hoạch học.")}><Plus size={14}/> Thêm nhiệm vụ</button>
     </section>
     <section className="panel"><div className="panelhead"><div><label>CONTINUE LEARNING</label><h2>Tiếp tục học</h2></div></div><div className="art"><div className="sun"/></div><div className="coursemeta"><b>ĐANG HỌC</b><span>6 chương · 24 bài</span></div><h3>Nền tảng năng lượng tái tạo</h3><p className="desc">Khám phá các nguồn năng lượng sạch và công nghệ chuyển đổi.</p><div className="taskmeta"><span>Tiến độ khóa học</span><b>42%</b></div><div className="bar"><i style={{width:"42%"}}/></div><button className="continue" onClick={()=>setNotice("Nội dung bài học sẽ được mở khi phân hệ khóa học hoàn tất.")}>Tiếp tục bài học <ArrowRight size={14}/></button></section>
     <section className="panel"><div className="panelhead"><div><label>YOUR LIBRARY</label><h2>Môn học của mày</h2></div><a>Tất cả <ArrowRight size={14}/></a></div>{subjects.length===0?<p className="desc">Chưa có môn học trong tài khoản. Thêm môn đầu tiên bên dưới nhé.</p>:subjects.map((x:any,i:number)=><div className="subject" key={x.id}><div className="subjecticon">{i%2===0?<BookOpen/>:<Sparkles/>}</div><div className="subjectinfo"><b>{x.name}</b><small>{x.courses?.length||0} khóa học</small><div className="bar"><i style={{width:"0%"}}/></div></div><strong>0%</strong></div>)}<form className="ask" onSubmit={addSubject}><input value={newSubject} onChange={e=>setNewSubject(e.target.value)} placeholder="Tên môn học mới..."/><button disabled={backendBusy||!newSubject.trim()}><Plus size={16}/></button></form></section>
     <section className="panel tutor" id="tutor"><div className="panelhead"><div><label>✦ AI LEARNING ASSISTANT</label><h2>Gia sư AI</h2></div><span className="online">● Trợ lý</span></div><div className="chat">{messages.slice(-4).map((m,i)=><div className={"bubble "+m.role} key={i}>{m.text}</div>)}{busy&&<div className="bubble assistant">Đang suy nghĩ...</div>}</div><form className="ask" onSubmit={ask}><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Hỏi AI bất cứ điều gì..."/><button disabled={busy||!question.trim()}><ArrowRight size={17}/></button></form><small className="disclaimer">AI có thể mắc lỗi. Hãy kiểm tra lại thông tin quan trọng.</small></section>
    </div>
    <section className="panel" style={{marginTop:16}}><div className="panelhead"><div><label>DATABASE SYNC</label><h2>Ghi nhận thời gian học</h2></div><span className="online">● Đã kết nối API</span></div><form className="ask" onSubmit={e=>{e.preventDefault();saveStudySession();}}><input type="number" min="1" max="1440" value={sessionMinutes} onChange={e=>setSessionMinutes(e.target.value)} aria-label="Số phút học"/><button disabled={backendBusy}>Lưu</button></form><p className="disclaimer">Phiên học được lưu vào PostgreSQL gắn với tài khoản đang đăng nhập.</p></section>
    <footer>© 2026 Learning Hub <span>Học tập theo cách của mày ✦</span></footer>
   </div>
  </section>
  {!user&&<div className="auth-backdrop"><form className="auth-card" onSubmit={submitAuth}><div className="brand" style={{padding:0,marginBottom:22}}><div className="brandmark"><BrainCircuit/></div><div><b>learning<span>hub</span></b><small>YOUR PERSONAL SPACE</small></div></div><h2>{authMode==="login"?"Đăng nhập Learning Hub":"Tạo tài khoản mới"}</h2><p className="muted-auth">Đăng nhập để lưu môn học và tiến độ học tập của mày.</p>{authMode==="register"&&<input required minLength={2} maxLength={60} value={authName} onChange={e=>setAuthName(e.target.value)} placeholder="Tên của mày"/>}<input required type="email" value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="Email"/><input required minLength={authMode==="register"?8:1} type="password" value={authPassword} onChange={e=>setAuthPassword(e.target.value)} placeholder="Mật khẩu (ít nhất 8 ký tự khi đăng ký)"/>{authError&&<div className="auth-error">{authError}</div>}<button className="primary auth-submit" disabled={authBusy}>{authBusy?"Đang xử lý...":authMode==="login"?"Đăng nhập":"Đăng ký tài khoản"}</button><button type="button" className="auth-switch" onClick={()=>{setAuthMode(authMode==="login"?"register":"login");setAuthError("");}}>{authMode==="login"?"Chưa có tài khoản? Đăng ký":"Đã có tài khoản? Đăng nhập"}</button></form></div>}
 </main>
}