import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

const schema = z.object({
  title: z.string().trim().min(1).max(120),
  description: z.string().max(2000).optional(),
  subjectId: z.string().min(1)
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const courses = await prisma.course.findMany({
    where: { subject: { userId: user.id } },
    include: { _count: { select: { lessons: true } }, subject: { select: { id: true, name: true, color: true } } },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ courses });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Chưa đăng nhập." }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Dữ liệu khóa học không hợp lệ." }, { status: 400 });
  const ownsSubject = await prisma.subject.findFirst({ where: { id: parsed.data.subjectId, userId: user.id } });
  if (!ownsSubject) return NextResponse.json({ error: "Không tìm thấy môn học." }, { status: 404 });
  const course = await prisma.course.create({ data: parsed.data });
  return NextResponse.json({ course }, { status: 201 });
}
